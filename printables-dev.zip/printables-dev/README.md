# Printables
## What is printables?
Printable is a onestop solutions for all your printing needs. From posters to stickers you can get everything. Here you can find the best stickers in low cost.What set's us apart, is that you can customize your stickers, poster and many things more....
## Features lists
 - [x] Categories
 - [x] Customization
 - [x] Huge collections
 - [x] Register, login
 - [x] Cart box
 - [x] Filter
 ## Tech stack
 - [x] HTML
 - [x] CSS
 - [x] Bootstrap
 - [x] JavaScript
 - [x] Django
 - [x] Figma
 - [x] Photoshop
 - [x] Iconic icons
 - [x] Font awesome    
## Sections
- [x] All categories
## SneakPeek of the website
#### **1** Home page
 ![Screenshot from 2023-02-26 10-10-12](https://user-images.githubusercontent.com/69218962/221392799-e0b49cbc-cc30-4751-922c-c3475c6878a8.png)
#### **2** Product page
 ![Screenshot from 2023-02-26 10-10-21](https://user-images.githubusercontent.com/69218962/221392948-ddcbced8-8c7d-49c8-a0f3-ab8f27a3d0e5.png)
#### **3** Product check out page
 ![Screenshot from 2023-02-26 10-10-57](https://user-images.githubusercontent.com/69218962/221393054-58648f03-449b-407f-b072-518b34de53c8.png)

